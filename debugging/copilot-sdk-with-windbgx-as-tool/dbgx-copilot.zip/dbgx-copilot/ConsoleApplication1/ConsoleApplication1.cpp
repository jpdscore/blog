﻿#pragma optimize("", off)
#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main()
{
    char* buffer = new char[8];
    scanf("%s", buffer);
    printf("%s\n", buffer);
    delete[] buffer;
}