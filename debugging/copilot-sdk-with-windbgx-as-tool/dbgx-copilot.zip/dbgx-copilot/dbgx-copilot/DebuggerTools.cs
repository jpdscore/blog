﻿using DbgX;
using DbgX.Interfaces.Enums;
using DbgX.Interfaces.Listeners;
using DbgX.Interfaces.Services.Internal;
using DbgX.Requests;
using DbgX.Requests.Initialization;
using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Diagnostics;
using System.Reflection;

namespace DbgXCopilot;

internal class DebuggerTools : IAsyncDisposable
{
    // DbgEng requires all interactions to be on the same thread, so we create a dedicated synchronization context and thread for it.
    private sealed class DebuggerSynchronizationContext : SynchronizationContext, IDisposable
    {
        private readonly BlockingCollection<(SendOrPostCallback Callback, object? State)> _queue = [];
        private readonly Thread _thread;

        public DebuggerSynchronizationContext()
        {
            _thread = new Thread(Run) { IsBackground = true, Name = nameof(DebuggerSynchronizationContext) };
            _thread.Start();
        }

        public override void Post(SendOrPostCallback d, object? state) => _queue.Add((d, state));

        private void Run()
        {
            SetSynchronizationContext(this);
            foreach (var (callback, state) in _queue.GetConsumingEnumerable())
                callback(state);
        }

        public void Dispose()
        {
            _queue.CompleteAdding();
            _thread.Join();
            _queue.Dispose();
        }
    }

    // Simple IDbgReporter implementation that logs to the provided ILogger.
    private class Reporter(ILogger logger) : IDbgReporter
    {
        private readonly ILogger _logger = logger;
        public void Error(bool _, string message) => _logger.LogError(message);
        public void Error(bool _, Exception exception, string? message = null) => _logger.LogError(exception, message);
        public void Info(string message) => _logger.LogInformation(message);
        public void Warning(string message) => _logger.LogWarning(message);
    }

    // Customization of engine paths to use the ones bundled with this application.
    // Note that current SymSvr NuGet package does not copy the binary.
    // Therefore, in this project, copying them to the output directory by MSbuild. 
    // See the .csproj file for the implementation to copy the binaries.
    private class EnginePathCustomization : IDbgEnginePathCustomization
    {
        public string HomeDirectory => Environment.ExpandEnvironmentVariables("%TEMP%");
        public string GetEngHostPath(string arch) => Path.Combine(GetEnginePath(arch), "EngHost.exe");
        public string GetEnginePath(string arch)
        {
            var assemblyDir = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            return Path.Combine(assemblyDir!, arch);
        }
    }

    // Override the default process creation to ensure the engine host process is created with the bundled binaries.
    private Process? CreateEngHostProcess(CreateOutOfProcessArgs args)
    {
        var psi = new ProcessStartInfo
        {
            FileName = args.EngHostPath,
            Arguments = args.Arguments,
            CreateNoWindow = true,
            UseShellExecute = false
        };
        return Process.Start(psi);
    }

    private readonly DebuggerSynchronizationContext _syncContext;
    private readonly DebugEngine _engine;

    internal static async Task<DebuggerTools> CreateAsync(ILoggerFactory loggerFactory)
    {
        DebuggerSynchronizationContext syncContext = new();
        return await InvokeAsync(syncContext, async () => new DebuggerTools(loggerFactory, syncContext));
    }

    private DebuggerTools(ILoggerFactory loggerFactory, DebuggerSynchronizationContext syncContext)
    {
        EnginePathCustomization customization = new();
        var logger = loggerFactory.CreateLogger<DebugEngine>();
        Reporter reporter = new(logger);
        _engine = new(customization, reporter, null, null, false, CreateEngHostProcess, syncContext, null, null);
        _syncContext = syncContext;
        _ensureNoShell = new(() => InvokeAsync(async () => await _engine.SendRequestAsync(new ExecuteRequest(".noshell"))));
    }

    public async ValueTask DisposeAsync()
    {
        try
        {
            await InvokeAsync(async () =>
            {
                _engine.Dispose();
                return true;
            });
        }
        catch (OperationCanceledException)
        {
            // Engine may cancel pending I/O during shutdown.
        }
        _syncContext.Dispose();
    }

    // Perform .noshell command to prevent accidentally running shell commands by AI.
    private readonly Lazy<Task> _ensureNoShell;
    private Task EnsureNoShellAsync() => _ensureNoShell.Value;

    [Description("指定されたパスのダンプ ファイルを開きます。既に開かれている場合は停止した後に開きます。")]
    public Task<bool> OpenDumpFile([Description("ダンプ ファイルのパス")] string filePath)
    {
        return InvokeAsync(async () =>
        {
            if (_engine.DebuggingState.TargetType != TargetType.NoTarget)
            {
                await _engine.StopDebuggingAsync();
            }
            return await _engine.SendRequestAsync(new OpenDumpFileRequest(filePath, new()));
        });
    }

    [Description("指定されたデバッガー コマンドを実行して結果を返します。")]
    public async Task<string> ExecuteDebuggerCommand([Description("デバッガー コマンド")] string command)
    {
        await EnsureNoShellAsync();
        return await InvokeAsync(async () => await _engine.SendRequestAsync(new ExecuteToStringRequest(command)));
    }

    #region Helper methods to marshal calls to the debugger synchronization context
    private Task<TResult> InvokeAsync<TResult>(Func<Task<TResult>> asyncAction) =>
        InvokeAsync(_syncContext, asyncAction);

    private static Task<TResult> InvokeAsync<TResult>(SynchronizationContext syncContext, Func<Task<TResult>> asyncAction)
    {
        TaskCompletionSource<TResult> tcs = new();
        syncContext.Post(_ =>
        {
            try
            {
                asyncAction().ContinueWith(task =>
                {
                    if (task.IsCanceled) tcs.TrySetCanceled();
                    else if (task.IsFaulted) tcs.TrySetException(task.Exception!.InnerExceptions);
                    else tcs.TrySetResult(task.Result);
                }, TaskScheduler.FromCurrentSynchronizationContext());
            }
            catch (Exception ex)
            {
                tcs.TrySetException(ex);
            }
        }, null);
        return tcs.Task;
    }
    #endregion
}