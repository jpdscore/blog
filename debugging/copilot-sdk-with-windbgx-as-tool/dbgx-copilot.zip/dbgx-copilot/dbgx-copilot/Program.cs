﻿using GitHub.Copilot.SDK;
using Microsoft.Extensions.AI;
using Microsoft.Extensions.Logging;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace DbgXCopilot;

internal class Program
{

    // システム プロンプト
    // AI の役割や振る舞いを定義するための指示で、ユーザーには見えない形でモデルに渡されます
    // すべての会話ターンに先立って適用され、応答のトーンや範囲の制御などを行うために使用できます。
    static readonly string _systemMessage = """
        あなたは WinDbgX のデバッガー エンジンを使用してアプリケーションの問題を診断するエージェントです。
        ダンプ ファイルや Time Travel Debugging トレースを分析し、原因の特定、解決策の提案を行います。
        また、トラブルシュートやデバッグに関する一般的な質問や相談にも答えます。
        あなたの応答はコンソールに表示されますので、表示されない可能性がある文字やマークダウンは使用しません。
        """;

    static async Task Main(string[] args)
    {
        using var loggerFactory = LoggerFactory.Create(builder => builder
            .AddDebug()
            .SetMinimumLevel(LogLevel.Trace));

        try
        {
            await RunAsync(loggerFactory);
        }
        finally
        {
            Console.ResetColor();
        }
    }

    private static async Task RunAsync(ILoggerFactory loggerFactory)
    {
        // (1) GitHub Copilot SDK を使用するための初期化
        CopilotClientOptions options = new()
        {
            Logger = loggerFactory.CreateLogger<CopilotClient>()
        };
        await using CopilotClient client = new(options);
        await client.StartAsync();

        // (2) 認証 (GitHub CLI でログイン済みの場合は不要)
        if (!await LoginIfNeeded(client))
        {
            Console.WriteLine("GitHub アカウントでのログインに失敗しました。");
            return;
        }

        // (3) セッションの開始
        await using var debuggerTools = await DebuggerTools.CreateAsync(loggerFactory);
        SessionConfig sessionConfig = new()
        {
            SystemMessage = new() { Content = _systemMessage },
            Model = await SelectModelAsync(client),
            Tools =
            [
                AIFunctionFactory.Create(EndConversation), // AI が会話の終了を判断したときに呼び出すツール
                AIFunctionFactory.Create(debuggerTools.OpenDumpFile), // ダンプ ファイルを開くツール
                AIFunctionFactory.Create(debuggerTools.ExecuteDebuggerCommand), // デバッガー コマンドを実行するツール
            ],
            OnPermissionRequest = PromptPermission
        };
        sessionConfig.Hooks = new()
        {
            OnPreToolUse = async (input, invocation) => {
                Console.ForegroundColor = ConsoleColor.DarkGray;
                Console.WriteLine($"\n[ツール呼び出し] ツール名: {input.ToolName}, 引数: {input.ToolArgs}");
                Console.ResetColor();
                return new() { PermissionDecision = "allow" };
            },
            OnPostToolUse = async (input, invocation) => {
                if (input.ToolName != "ExecuteDebuggerCommand")
                {
                    return null;
                }
                var toolResultString = input.ToolResult?.ToString()
                    ?? throw new Exception("ツールの実行結果が取得できませんでした。");
                var toolResult = JsonSerializer.Deserialize<ToolResultObject>(toolResultString)
                    ?? throw new InvalidOperationException("ツールの実行結果のデシリアライズに失敗しました。");

                if (!toolResult.ResultType.Equals("success", StringComparison.OrdinalIgnoreCase))
                {
                    return null;
                }

                bool masked = false;
                var maskedToolResultString = Regex.Replace(
                    toolResult.TextResultForLlm,
                    @"[a-zA-Z0-9._%+-]+@([a-zA-Z0-9.-]+)(\.[a-zA-Z]{2,})",
                    m =>
                    {
                        masked = true;
                        return Regex.Replace(m.Value, @"[a-zA-Z0-9_%+\-]", "*");
                    });
                if (masked)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"\n[マスク処理] ツール出力に含まれるメール アドレスをマスクしました。");
                    Console.ResetColor();
                    toolResult.TextResultForLlm = maskedToolResultString;
                    return new() { ModifiedResult = toolResult };
                }

                return null;
            },
        };
        await using var session = await client.CreateSessionAsync(sessionConfig);

        // (4) イベント ハンドラーの追加
        TaskCompletionSource done = new();
        session.On(evt =>
        {
            switch (evt)
            {
                // AI からのメッセージ受信イベント
                case AssistantMessageEvent msg:
                    if (!string.IsNullOrEmpty(msg.Data.Content))
                    {
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        Console.WriteLine($"\n[アシスタント]\n{msg.Data.Content}");
                        Console.ResetColor();
                    }
                    break;

                // ユーザーのプロンプトに対する AI の応答が完了しアイドル状態になったイベント
                case SessionIdleEvent:
                    done.TrySetResult();
                    break;
            }
        });

        // (5) 会話ループ

        // エージェントから説明させるため初期プロンプト
        await session.SendAsync(new MessageOptions { Prompt = "挨拶して、あなたができることを簡潔に説明してください。" });
        await done.Task;

        // 終了フラグが立つまでプロンプト送信と応答を繰り返す
        while (!exitRequested)
        {
            done = new TaskCompletionSource();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n[プロンプト]");
            Console.ResetColor();
            string? userPrompt = Console.ReadLine();
            await session.SendAsync(new MessageOptions { Prompt = userPrompt! });
            await done.Task;
        }
    }

    // 認証されていない場合は GitHub ログインを実行します。
    private static async Task<bool> LoginIfNeeded(CopilotClient client)
    {
        var authStatus = await client.GetAuthStatusAsync();
        if (!authStatus.IsAuthenticated)
        {
            ProcessStartInfo psi = new()
            {
                FileName = GetBundledCliPath(),
                Arguments = "login",
                UseShellExecute = true,
            };
            Console.WriteLine(psi.FileName + " " + psi.Arguments);
            using var p = Process.Start(psi);
            p?.WaitForExit();

            authStatus = await client.GetAuthStatusAsync();
            if (!authStatus.IsAuthenticated)
            {
                return false;
            }
        }
        return true;
    }

    // NuGet パッケージに同梱されている Copilot CLI のパスを取得します。
    static string GetBundledCliPath()
    {
        var portableRid = RuntimeInformation.OSArchitecture switch
        {
            Architecture.X64 => "win-x64",
            Architecture.Arm64 => "win-arm64",
            _ => throw new PlatformNotSupportedException()
        };
        var executablePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        return Path.Combine(executablePath!, "runtimes", portableRid, @"native\copilot.exe");
    }

    // 利用可能なモデルを表示してユーザーに選択させた結果を返します。
    static async Task<string> SelectModelAsync(CopilotClient client)
    {
        var models = await client.ListModelsAsync();
        foreach (var (model, i) in models.Select((model, i) => (model, i)))
        {
            Console.WriteLine($"[{i:d2}] {model.Id,-26} {model.Billing?.Multiplier}x");
        }

        Console.Write("モデルの番号を選択してください (既定値:0): ");
        int.TryParse(Console.ReadLine(), out var selectedIndex);
        return models[Math.Clamp(selectedIndex, 0, models.Count - 1)].Id;
    }

    // AI から会話を終了するときに AI が呼び出すツールと終了フラグ
    static bool exitRequested = false;

    [DisplayName(nameof(EndConversation))]
    [Description("""
        ユーザーが会話の終了を意図していると判断した場合に呼び出します。
        （例: 'さようなら', '終了', 'bye', 'quit' など）。
        """)]
    static void EndConversation()
    {
        exitRequested = true;
    }

    // 許可の要求イベントのハンドラー
    static async Task<PermissionRequestResult> PromptPermission(PermissionRequest request, PermissionInvocation invocation)
    {
        switch (request)
        {
            case PermissionRequestCustomTool requestForCustomTool:
                // 会話終了ツールの場合は常に承認します。
                if (requestForCustomTool.ToolName == nameof(EndConversation))
                {
                    return new() { Kind = PermissionRequestResultKind.Approved };
                }
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("\n[確認]");
                Console.WriteLine("AI が以下の操作を実行しようとしています。");
                Console.WriteLine($"- ツール名: {requestForCustomTool.ToolName}");
                Console.WriteLine($"- 引数: {requestForCustomTool.Args}");
                Console.WriteLine("許可しますか？ ([Y]es / [N]o)");

                string? input = Console.ReadLine()?.Trim().ToUpperInvariant();
                Console.ResetColor();
                if (input is "Y" or "YES")
                {
                    return new() { Kind = PermissionRequestResultKind.Approved };
                }
                else
                {
                    return new() { Kind = PermissionRequestResultKind.DeniedInteractivelyByUser };
                }

            default:
                // MCP ツールなど他の承認要求の処理は実装を省略しています。
                return new() { Kind = PermissionRequestResultKind.Approved };
        }
    }

}