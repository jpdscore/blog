﻿using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Hello world.");
            GC.Collect();
        }
    }
}
