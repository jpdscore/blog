// Profiler.cpp : Implementation of CProfiler

#include "pch.h"
#include "Profiler.h"
#include <stdio.h>
#pragma comment(lib, "corguids.lib")

void DoBadThing()
{
	int* p = (int*)0xabababab;
	*p = 0;
}

STDMETHODIMP CProfiler::Initialize(IUnknown* pICorProfilerInfoUnk)
{
	printf("[Profiler] Initialize MyNetFxProfiler.\n");

	ICorProfilerInfo* pICorProfilerInfo;
	HRESULT hr;
	
	hr = pICorProfilerInfoUnk->QueryInterface(IID_ICorProfilerInfo, (LPVOID*)&pICorProfilerInfo);
	if (FAILED(hr))
		return E_FAIL;

	COR_PRF_MONITOR mask = COR_PRF_MONITOR::COR_PRF_MONITOR_GC;
	hr = pICorProfilerInfo->SetEventMask(mask);
	if (FAILED(hr))
		return E_FAIL;

	pICorProfilerInfo->Release();
	pICorProfilerInfo = nullptr;

	// This triggers being shown dialog "CLR Error: 80004005."
	// DoBadThing();

	return S_OK;
}

STDMETHODIMP CProfiler::Shutdown()
{
	printf("[Profiler] Shutdown MyNetFxProfiler.\n");
	return S_OK;
}

STDMETHODIMP CProfiler::GarbageCollectionStarted(int cGenerations, BOOL generationCollected[], COR_PRF_GC_REASON reason)
{
	printf("[Profiler] GC started Reason=%d.\n", reason);

	// This triggers .NET Runtime EventID 1023.
	// DoBadThing();

	return S_OK;
}

STDMETHODIMP CProfiler::GarbageCollectionFinished()
{
	printf("[Profiler] GC finished.\n");
	return S_OK;
}

