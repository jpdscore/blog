// dllmain.h : Declaration of module class.

class CMyNetFxProfilerModule : public ATL::CAtlDllModuleT< CMyNetFxProfilerModule >
{
public :
	DECLARE_LIBID(LIBID_MyNetFxProfilerLib)
	DECLARE_REGISTRY_APPID_RESOURCEID(IDR_MYNETFXPROFILER, "{3eaa7474-770a-4eb4-870c-188bedb1166b}")
};

extern class CMyNetFxProfilerModule _AtlModule;
